Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/bmp180_simpletest.py
    :caption: examples/bmp180_simpletest.py
    :lines: 5-
